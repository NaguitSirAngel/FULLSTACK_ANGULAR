import { Component, OnInit, AfterViewInit } from "@angular/core";
import { getLocaleDateFormat } from "@angular/common";
import * as moment from "moment";

@Component({
  selector: "app-students",
  template: `
    <h1>{{ title }} - ( {{ getCurrentDate() }} )</h1>
  `,
  styleUrls: ["./students.component.css"]
})
export class StudentsComponent implements OnInit {
  title: string = "My List of Students";

  constructor() {}

  getTitle() {
    return this.title;
  }

  getCurrentDate() {
    return moment().format("MMMM Do YYYY, h:mm:ss a");
  }
  ngOnInit() {
    console.log("onInit");
  }

  ngAfterViewInit() {
    console.log("afterViewInit");
  }
}
