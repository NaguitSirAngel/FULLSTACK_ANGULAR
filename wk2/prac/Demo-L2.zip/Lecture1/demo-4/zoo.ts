// Modules ...using class export
//import { Penguin } from "./animals";

class zoo {
  constructor() {}
}

//let p = new Penguin();
