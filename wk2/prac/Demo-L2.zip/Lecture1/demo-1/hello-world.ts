var greeter = (firstName, lastName) => {
  console.log(`Hello world ${firstName} ${lastName}`);
};

greeter("Mike", "Denton");
